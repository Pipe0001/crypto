# Do not expose your Neon credentials to the browser

PGHOST='ep-billowing-sound-a56q2fm7.us-east-2.aws.neon.tech'
PGDATABASE='neondb'
PGUSER='neondb_owner'
PGPASSWORD='keNj0TpRK3aL'